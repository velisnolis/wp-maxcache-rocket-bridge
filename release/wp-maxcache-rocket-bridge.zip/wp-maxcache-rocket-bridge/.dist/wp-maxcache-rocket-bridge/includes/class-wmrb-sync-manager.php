<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WMRB_Sync_Manager {
	const STATE_OPTION_KEY = 'wmrb_sync_state';
	const BACKUP_DIR_NAME  = 'wmrb-backups';

	/**
	 * @var WMRB_Snippet_Service
	 */
	private $snippet_service;

	/**
	 * @var array<string,mixed>
	 */
	private $options;

	/**
	 * @param array<string,mixed> $options
	 */
	public function __construct( WMRB_Snippet_Service $snippet_service, array $options ) {
		$this->snippet_service = $snippet_service;
		$this->options         = $options;
		$this->register_hooks();
	}

	private function register_hooks() {
		add_action( 'update_option_wp_rocket_settings', array( $this, 'handle_rocket_settings_update' ), 10, 3 );
		add_action( 'admin_init', array( $this, 'maybe_backfill_state' ) );
	}

	public function maybe_backfill_state() {
		$state = get_option( self::STATE_OPTION_KEY, array() );
		if ( is_array( $state ) && ! empty( $state['current_hash'] ) ) {
			return;
		}

		$current_hash = $this->snippet_service->get_sync_fingerprint();
		$initial = array(
			'status'             => 'in_sync',
			'current_hash'       => $current_hash,
			'last_applied_hash'  => $current_hash,
			'last_change_at'     => current_time( 'mysql' ),
			'last_applied_at'    => current_time( 'mysql' ),
		);
		update_option( self::STATE_OPTION_KEY, $initial, false );
	}

	/**
	 * @param mixed $old_value
	 * @param mixed $value
	 * @param string $option
	 */
	public function handle_rocket_settings_update( $old_value, $value, $option ) {
		unset( $old_value, $value, $option );

		if ( empty( $this->options['auto_sync_enabled'] ) ) {
			return;
		}

		$state = $this->refresh_state_from_current_fingerprint();

		if ( ! empty( $this->options['auto_apply_htaccess'] ) && isset( $state['status'] ) && 'pending_apply' === $state['status'] ) {
			$this->apply_snippet_to_htaccess();
		}
	}

	public function refresh_state_from_current_fingerprint() {
		$current_hash = $this->snippet_service->get_sync_fingerprint();
		$state        = $this->get_state();
		$last_applied = isset( $state['last_applied_hash'] ) ? (string) $state['last_applied_hash'] : '';

		// First run: assume current snippet is applied to avoid false pending status.
		if ( '' === $last_applied ) {
			$last_applied = $current_hash;
		}

		$status       = $current_hash === $last_applied ? 'in_sync' : 'pending_apply';

		$next = array(
			'status'            => $status,
			'current_hash'      => $current_hash,
			'last_applied_hash' => $last_applied,
			'last_change_at'    => current_time( 'mysql' ),
			'last_applied_at'   => isset( $state['last_applied_at'] ) ? (string) $state['last_applied_at'] : '',
			'last_backup_file'  => isset( $state['last_backup_file'] ) ? (string) $state['last_backup_file'] : '',
			'last_error'        => isset( $state['last_error'] ) ? (string) $state['last_error'] : '',
		);

		update_option( self::STATE_OPTION_KEY, $next, false );
		return $next;
	}

	/**
	 * @return array<string,string>
	 */
	public function mark_applied() {
		$current_hash = $this->snippet_service->get_sync_fingerprint();
		$state        = $this->get_state();

		$next = array(
			'status'            => 'in_sync',
			'current_hash'      => $current_hash,
			'last_applied_hash' => $current_hash,
			'last_change_at'    => isset( $state['last_change_at'] ) ? (string) $state['last_change_at'] : current_time( 'mysql' ),
			'last_applied_at'   => current_time( 'mysql' ),
			'last_backup_file'  => isset( $state['last_backup_file'] ) ? (string) $state['last_backup_file'] : '',
			'last_error'        => '',
		);

		update_option( self::STATE_OPTION_KEY, $next, false );
		return $next;
	}

	/**
	 * @return array<string,string>
	 */
	public function get_state() {
		$state = get_option( self::STATE_OPTION_KEY, array() );
		if ( ! is_array( $state ) ) {
			$state = array();
		}

		$defaults = array(
			'status'            => 'in_sync',
			'current_hash'      => '',
			'last_applied_hash' => '',
			'last_change_at'    => '',
			'last_applied_at'   => '',
			'last_backup_file'  => '',
			'last_error'        => '',
		);

		return wp_parse_args( $state, $defaults );
	}

	/**
	 * @return array<string,string>
	 */
	public function apply_snippet_to_htaccess() {
		$htaccess_path = ABSPATH . '.htaccess';
		$state         = $this->get_state();

		if ( ! file_exists( $htaccess_path ) || ! is_readable( $htaccess_path ) || ! is_writable( $htaccess_path ) ) {
			$state['status']     = 'pending_apply';
			$state['last_error'] = '.htaccess no accessible (read/write).';
			update_option( self::STATE_OPTION_KEY, $state, false );
			return $state;
		}

		$original = (string) file_get_contents( $htaccess_path );
		$backup   = $this->create_backup( $original );
		if ( '' === $backup ) {
			$state['status']     = 'pending_apply';
			$state['last_error'] = 'No s’ha pogut crear backup de .htaccess.';
			update_option( self::STATE_OPTION_KEY, $state, false );
			return $state;
		}

		$snippet  = rtrim( $this->snippet_service->get_snippet() ) . "\n";
		$updated  = $this->upsert_wmrb_block( $original, $snippet );
		$written  = file_put_contents( $htaccess_path, $updated );

		if ( false === $written ) {
			$state['status']          = 'pending_apply';
			$state['last_backup_file']= $backup;
			$state['last_error']      = 'No s’ha pogut escriure .htaccess.';
			update_option( self::STATE_OPTION_KEY, $state, false );
			return $state;
		}

		$state                    = $this->mark_applied();
		$state['last_backup_file']= $backup;
		$state['last_error']      = '';
		update_option( self::STATE_OPTION_KEY, $state, false );
		return $state;
	}

	/**
	 * @return array<string,string>
	 */
	public function rollback_last_backup() {
		$state = $this->get_state();
		$file  = isset( $state['last_backup_file'] ) ? (string) $state['last_backup_file'] : '';
		if ( '' === $file || ! file_exists( $file ) || ! is_readable( $file ) ) {
			$state['last_error'] = 'No hi ha backup vàlid per rollback.';
			update_option( self::STATE_OPTION_KEY, $state, false );
			return $state;
		}

		$htaccess_path = ABSPATH . '.htaccess';
		$content       = (string) file_get_contents( $file );
		$written       = file_put_contents( $htaccess_path, $content );
		if ( false === $written ) {
			$state['last_error'] = 'Rollback fallit: no es pot escriure .htaccess.';
			update_option( self::STATE_OPTION_KEY, $state, false );
			return $state;
		}

		$state['status']       = 'pending_apply';
		$state['current_hash'] = $this->snippet_service->get_sync_fingerprint();
		$state['last_error']   = '';
		update_option( self::STATE_OPTION_KEY, $state, false );
		return $state;
	}

	private function upsert_wmrb_block( $content, $snippet ) {
		$pattern = '/\# BEGIN WMRB suggested MaxCache snippet.*?\# END WMRB suggested MaxCache snippet\s*/s';
		if ( preg_match( $pattern, $content ) ) {
			return (string) preg_replace( $pattern, $snippet . "\n", $content );
		}

		$trimmed = rtrim( $content );
		return $trimmed . "\n\n" . $snippet;
	}

	private function create_backup( $content ) {
		$dir = WP_CONTENT_DIR . '/' . self::BACKUP_DIR_NAME;
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		$file = $dir . '/htaccess-' . gmdate( 'Ymd-His' ) . '.bak';
		$ok   = file_put_contents( $file, $content );
		return false === $ok ? '' : $file;
	}
}
